module.exports = global.config = {
    i18n: {
        user: {
            user_id: "",
            useremail : "",
            user_type :"",
            user_verified :""
        }
    }
};