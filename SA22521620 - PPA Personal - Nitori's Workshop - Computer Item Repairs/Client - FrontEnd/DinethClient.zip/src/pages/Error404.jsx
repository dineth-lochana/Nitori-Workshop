
import React from "react";
import RibbonHead from './RibbonHead.jsx';
import RibbonFoot from './RibbonFoot.jsx';
import './Homepage.css'

const Error404 = () => {
  return (
    <div>
      <RibbonHead />
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <h1 align="center" className="welcome justify-content-center align-items-center">Page Not Found!</h1>
       

        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>
        <br/>

      <RibbonFoot />
    
    </div>
  );
};

export default Error404;
