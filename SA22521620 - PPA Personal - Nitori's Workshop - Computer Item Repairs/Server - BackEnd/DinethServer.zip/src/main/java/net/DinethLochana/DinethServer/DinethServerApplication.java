package net.DinethLochana.DinethServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DinethServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DinethServerApplication.class, args);
	}

}
