package net.DinethLochana.DinethServer.repository;

import net.DinethLochana.DinethServer.entity.Computer_Item;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Computer_Item_Repository extends JpaRepository<Computer_Item, Integer> {

}
