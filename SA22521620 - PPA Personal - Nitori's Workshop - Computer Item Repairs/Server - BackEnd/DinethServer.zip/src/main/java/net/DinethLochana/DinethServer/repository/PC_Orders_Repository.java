package net.DinethLochana.DinethServer.repository;

import net.DinethLochana.DinethServer.entity.PC_Orders;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface PC_Orders_Repository extends JpaRepository<PC_Orders, Integer> {

}
