package net.DinethLochana.DinethServer.repository;

import net.DinethLochana.DinethServer.entity.PC_Part;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PC_Part_Repository extends JpaRepository<PC_Part, Integer> {

}
