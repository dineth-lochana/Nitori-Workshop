package net.DinethLochana.DinethServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DinethServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
